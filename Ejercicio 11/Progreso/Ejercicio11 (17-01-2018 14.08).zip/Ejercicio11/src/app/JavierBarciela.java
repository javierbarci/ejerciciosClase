/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import javax.swing.JOptionPane;
import util.Util;
import modelo.Equipo;

/**
 *
 * @author daw1
 */
public class JavierBarciela {
    
    private static Equipo[] equipos = new Equipo[20];
    
    public static void main(String[] args) {
        
        cargarDatosEquipos();
        String resp = JOptionPane.showInputDialog(null, mostrarMenu());
        int opc = Integer.parseInt(resp);
        switch(opc){
            case 1:
                verClasificación();
                break;
        }
        
        /* PROBAR FUNCIONAMIENTO: CARGAR Y COMPROBAR PUNTOS EN BASE AL EQUIPO
        String resp = JOptionPane.showInputDialog(null, "Introduce la posición del equipo");
        int posicion = Integer.parseInt(resp);
        JOptionPane.showMessageDialog(null, equipos[posicion].getPuntos());
        */
    }
    
    private static void cargarDatosEquipos(){
        for(int pos=0; pos<equipos.length; pos++){
            equipos[pos] = new Equipo(pos);
            for(int i=0; i<Util.partidos.length; i++){
                if(Util.partidos[i].getGolesLocal() != -1){
                    equipos[pos].añadirResultado(Util.partidos[i]);
                }
            }
        }
        
    }
    
    private static String mostrarMenu(){
        return              "Liga Profesional\n\n" +
                            "1. Ver Clasificación\n" +
                            "2. Ver Jornada\n" +
                            "3. Añadir Resultados\n" +
                            "4. Modificar Resultado\n" +
                            "5. Equipos Más Goleadores\n" +
                            "6. Equipos Menos Goleados\n" +
                            "7. Equipos con Mejor Diferencia de Goles\n" +
                            "8. Equipos con Peor Diferencia de Goles\n" +
                            "9. Pronóstico Quiniela\n" +
                            "10. Salir\n\n" +
                            "Opción [1-9]";
    }
    
    private static void verClasificación(){ // SELECCIÓN
        ordenarPorSeleccion();
        String listado =   "<html><body><table>";
        listado +=         "<tr><th>Equipo</th>"
                            + "<th>PJ</th>"
                            + "<th>G</th>"
                            + "<th>E</th>"
                            + "<th>P</th>"
                            + "<th>GF</th>"
                            + "<th>GC</th>"
                            + "<th>Ptos</th></tr>";
        for (int i=0; i<equipos.length; i++){
            listado += "<tr><th>" + Equipo.getNombre(equipos[i].getPos()) + "</th></tr>"; //he tenido que cambiar getNombre a static
        } 
        JOptionPane.showMessageDialog(null, listado);
    }
    
    private static void ordenarPorSeleccion(){
        int i,j,mayor;
        Equipo temp;
        for(i=0; i<equipos.length-1; i++){
            mayor = i;
            for(j=i+1; j<equipos.length; j++){
                if (equipos[j].getPuntos() > equipos[i].getPuntos()){
                    mayor = j;
                }
            }
            if (mayor != i){
                temp = equipos[i];
                equipos[i] = equipos[mayor];
                equipos[mayor] = temp;
            }
        }
    }
    
    private static void verJornada(){ // BÚSQUEDA ORDENADA
        
    }
    
    private static void modificarResultado(){ // BÚSQUEDA DESORDENADA
        
    }
    
    private static void masGoleadores(){ // BURBUJA
        
    }
    
    private static void mejorDiferencia(){ // INSERCIÓN
        
    }
    
}
