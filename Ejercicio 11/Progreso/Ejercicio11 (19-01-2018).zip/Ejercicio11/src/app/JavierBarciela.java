/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import javax.swing.JOptionPane;
import util.Util;
import modelo.Equipo;

/**
 *
 * @author daw1
 */
public class JavierBarciela {
    
    private static Equipo[] equipos = new Equipo[20];
    
    public static void main(String[] args) {
        
        cargarDatosEquipos();
        String resp;
        int opc;
        do {
            resp = JOptionPane.showInputDialog(null, mostrarMenu());
            opc = Integer.parseInt(resp);
            switch(opc){
                case 1:
                    verClasificación();
                    break;
                case 7:
                    mejorDiferencia();
                    break;
            }
        } while (opc != 10);
        /* PROBAR FUNCIONAMIENTO: CARGAR Y COMPROBAR PUNTOS EN BASE AL EQUIPO
        String resp = JOptionPane.showInputDialog(null, "Introduce la posición del equipo");
        int posicion = Integer.parseInt(resp);
        JOptionPane.showMessageDialog(null, equipos[posicion].getPuntos());
        */
    }
    
    private static void cargarDatosEquipos(){
        for(int pos=0; pos<equipos.length; pos++){
            equipos[pos] = new Equipo(pos);
            for(int i=0; i<Util.partidos.length; i++){
                if(Util.partidos[i].getGolesLocal() != -1){
                    equipos[pos].añadirResultado(Util.partidos[i]);
                }
            }
        }
        
    }
    
    private static String mostrarMenu(){
        return              "Liga Profesional\n\n" +
                            "1. Ver Clasificación\n" +
                            "2. Ver Jornada\n" +
                            "3. Añadir Resultados\n" +
                            "4. Modificar Resultado\n" +
                            "5. Equipos Más Goleadores\n" +
                            "6. Equipos Menos Goleados\n" +
                            "7. Equipos con Mejor Diferencia de Goles\n" +
                            "8. Equipos con Peor Diferencia de Goles\n" +
                            "9. Pronóstico Quiniela\n" +
                            "10. Salir\n\n" +
                            "Opción [1-9]";
    }
    
    private static void verClasificación(){ // SELECCIÓN
        clasificacionSeleccion();
        String listado =   "<html><body><table bgcolor='#FFFFFF'>";
        listado +=         "<tr><th colspan='2'>Equipo</th>"
                            + "<th>PJ</th>"
                            + "<th>G</th>"
                            + "<th>E</th>"
                            + "<th>P</th>"
                            + "<th>GF</th>"
                            + "<th>GC</th>"
                            + "<th>Ptos</th></tr>";
        for (int i=0; i<equipos.length; i++){
            listado += "<tr><td><img src='file:" + equipos[i].getPos() + ".jpg' style='float:left' height='25'  width='25' /></td>"
                    + "<td>" + equipos[i].getNombre(equipos[i].getPos()) + "</td>"
                    + "<td>" + equipos[i].getPartidosJugados() + "</td>"
                    + "<td>" + equipos[i].getGanados() + "</td>"
                    + "<td>" + equipos[i].getEmpatados() + "</td>"
                    + "<td>" + equipos[i].getPerdidos() + "</td>"
                    + "<td>" + equipos[i].getGolesFavor() + "</td>"
                    + "<td>" + equipos[i].getGolesContra() + "</td>"
                    + "<td><big>" + equipos[i].getPuntos() + "</big></td>"
                    + "</tr>";
        } 
        listado += "</table></body></html>";
        JOptionPane.showMessageDialog(null, listado, "Clasificación", JOptionPane.PLAIN_MESSAGE);
    }
    
    private static void clasificacionSeleccion(){
        int i,j,mayor;
        Equipo temp;
        for(i=0; i<equipos.length-1; i++){
            mayor = i;
            for(j=i+1; j<equipos.length; j++){
                if (equipos[j].getPuntos() > equipos[mayor].getPuntos()){
                    mayor = j;
                }
            }
            if (mayor != i){
                temp = equipos[i];
                equipos[i] = equipos[mayor];
                equipos[mayor] = temp;
            }
        }
    }
    
    private static void verJornada(){ // BÚSQUEDA ORDENADA
        
    }
    
    private static void modificarResultado(){ // BÚSQUEDA DESORDENADA
        
    }
    
    private static void masGoleadores(){ // BURBUJA
        masGoleadoresBurbuja();
        
    }
    
    private static void masGoleadoresBurbuja(){
        
    }
    
    private static void mejorDiferencia(){ // INSERCIÓN
        mejorDiferenciaInsercion();
        String listado =   "<html><body><table bgcolor='#FFFFFF'>";
        listado +=         "<tr><th colspan='2'>Equipo</th>"
                            + "<th>Diferencia goles</th></tr>";
        int i;
        for (i=0; i<7; i++){ // ESTÁ HECHO PARA QUE SALGAN LOS 6 PRIMEROS Y LA SEGUNDA REPETITIVA TENGA REPERCUSIÓN EN LA TABLA
            listado += "<tr><td><img src='file:" + equipos[i].getPos() + ".jpg' style='float:left' height='25'  width='25' /></td>"
                    + "<td>" + equipos[i].getNombre(equipos[i].getPos()) + "</td>"
                    + "<td>" + equipos[i].getDiferenciaGoles()+ "</td></tr>";
        } 
        for (i=6; equipos[i].getDiferenciaGoles() == equipos[i+1].getDiferenciaGoles(); i++){
            listado += "<tr><td><img src='file:" + equipos[i+1].getPos() + ".jpg' style='float:left' height='25'  width='25' /></td>"
                    + "<td>" + equipos[i+1].getNombre(equipos[i+1].getPos()) + "</td>"
                    + "<td>" + equipos[i+1].getDiferenciaGoles()+ "</td></tr>";
        }
        listado += "</tr></table></body></html>";
        JOptionPane.showMessageDialog(null, listado, "Mejor diferencia", JOptionPane.PLAIN_MESSAGE);
    }
    
    private static void mejorDiferenciaInsercion(){ 
        int i,j;
        Equipo temp;
        for(i=0; i<equipos.length-1; i++){
            for(j=0; j<equipos.length; j++){
                if(equipos[j].getDiferenciaGoles() < equipos[i].getDiferenciaGoles()){
                    temp = equipos[i];
                    equipos[i] = equipos[j];
                    equipos[j] = temp;
                }
            }
        }
    }
    
}
